function execute() {
    return Response.success([
        {title: "Action", input: "https://lnmtl.com/novel?genre=action&page=", script: "gen.js"},
        {title: "Adventure", input: "https://lnmtl.com/novel?genre=adventure&page=", script: "gen.js"},
        {title: "Comedy", input: "https://lnmtl.com/novel?genre=comedy&page=", script: "gen.js"},
        {title: "Drama", input: "https://lnmtl.com/novel?genre=drama&page=", script: "gen.js"},
        {title: "Ecchi", input: "https://lnmtl.com/novel?genre=ecchi&page=", script: "gen.js"},
        {title: "Fantasy", input: "https://lnmtl.com/novel?genre=fantasy&page=", script: "gen.js"},
        {title: "Harem", input: "https://lnmtl.com/novel?genre=harem&page=", script: "gen.js"},
        {title: "Martial-arts", input: "https://lnmtl.com/novel?genre=martial-arts&page=", script: "gen.js"},
        {title: "Mature", input: "https://lnmtl.com/novel?genre=mature&page=", script: "gen.js"},
        {title: "Mystery", input: "https://lnmtl.com/novel?genre=mystery&page=", script: "gen.js"},
        {title: "Romance", input: "https://lnmtl.com/novel?genre=romance&page=", script: "gen.js"},
        {title: "school-life", input: "https://lnmtl.com/novel?genre=school-life&page=", script: "gen.js"},
        {title: "sci-fi", input: "https://lnmtl.com/novel?genre=sci-fi&page=", script: "gen.js"},
        {title: "seinen", input: "https://lnmtl.com/novel?genre=seinen&page=", script: "gen.js"},
        {title: "slice-of-life", input: "https://lnmtl.com/novel?genre=slice-of-life&page=", script: "gen.js"},
        {title: "tupernatural", input: "https://lnmtl.com/novel?genre=supernatural&page=", script: "gen.js"},
        {title: "Tragedy", input: "https://lnmtl.com/novel?genre=tragedy&page=", script: "gen.js"},
        {title: "Xianxia", input: "https://lnmtl.com/novel?genre=xianxia&page=", script: "gen.js"},
        {title: "Xuanhuan", input: "https://lnmtl.com/novel?genre=xuanhuan&page=", script: "gen.js"}
    ]);
}