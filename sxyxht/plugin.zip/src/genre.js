function execute() {
    return Response.success([
        {title : "玄幻小说", input : "https://m.sxyxht.com/xuanhuan/page_", script : "gen.js"},
        {title : "修真小说", input : "https://m.sxyxht.com/xiuzhen/page_", script : "gen.js"},
        {title : "都市小说", input : "https://m.sxyxht.com/dushi/page_", script : "gen.js"},
        {title : "历史小说", input : "https://m.sxyxht.com/lishi/page_", script : "gen.js"},
        {title : "网游小说", input : "https://m.sxyxht.com/wangyou/page_", script : "gen.js"},
        {title : "科幻小说", input : "https://m.sxyxht.com/kehuan/page_", script : "gen.js"},
        {title : "女频小说", input : "https://m.sxyxht.com/nvpin/page_", script : "gen.js"},
    ])
}