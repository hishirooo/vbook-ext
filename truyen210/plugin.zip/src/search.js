function execute(key, page) {
	var doc = Http.get("https://truyen210.net/tim-kiem?q=" +  key).html()
    var books = doc.select(".category-content .manga-list ul").first().select("li")

    var listBook = [];

    books.forEach(book => listBook.push({
        name: book.select(".manga-thumb img").attr("alt"),
        link: book.select(".manga-info h3 a").attr("href"),
        cover: book.select(".manga-thumb img").attr("data-original"),
        description: book.select(".box-manga-info a").text() + ", " + book.select(".box-manga-info .time").text(),
        host: "https://truyen210.net/"
    }))

    // if (listBook.length == 0) next = ""; 
    // else next = (parseInt(page) + 1).toString();
    return Response.success(listBook)
    
}