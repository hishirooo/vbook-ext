function execute(url) {
    var doc = Http.get(url).html()
    var books = doc.select("#tags")
    return Response.success(doc)
}