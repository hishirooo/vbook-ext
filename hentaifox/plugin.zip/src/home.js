function execute() {
    return Response.success([
        {title: "Latest", input: "https://hentaifox.com/pag/", script: "gen.js"}
    ])
}