function execute() {
    return Response.success([
    {title : "Tất cả", input : "tat-ca", script: "gen.js" },
    ])
}