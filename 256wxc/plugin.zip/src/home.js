function execute() {
    return Response.success([

        { title: "现代耽美", input: "https://www.256wenku.com/xiandai/", script: "gen.js" },
        { title: "古代架空", input: "https://www.256wenku.com/jiakong/", script: "gen.js" },
        { title: "穿越重生", input: "https://www.256wenku.com/chuanyue/", script: "gen.js" },
        { title: "BL同人", input: "https://www.256wenku.com/bltongren/", script: "gen.js" },
        { title: "GL百合", input: "https://www.256wenku.com/glbaihe/", script: "gen.js" }, 
        { title: "玄幻科幻", input: "https://www.256wenku.com/xuanhuan/", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wenku.com/yanqing/", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wenku.com/gudaiyanqing/", script: "gen.js" }, 
    ]);
}