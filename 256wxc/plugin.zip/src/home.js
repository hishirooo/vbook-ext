function execute() {
    return Response.success([

        { title: "现代耽美", input: "https://www.256wenku.com/xiandai/index", script: "gen.js" },
        { title: "古代架空", input: "https://www.256wenku.com/jiakong/index", script: "gen.js" },
        { title: "穿越重生", input: "https://www.256wenku.com/chuanyue/index", script: "gen.js" },
        { title: "BL同人", input: "https://www.256wenku.com/bltongren/index", script: "gen.js" },
        { title: "GL百合", input: "https://www.256wenku.com/glbaihe/index", script: "gen.js" }, 
        { title: "玄幻科幻", input: "https://www.256wenku.com/xuanhuan/index", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wenku.com/yanqing/index", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wenku.com/gudaiyanqing/index", script: "gen.js" }, 
    ]);
}