function execute() {
    return Response.success([

        { title: "现代耽美", input: "https://www.256wxc.com/xiandai/index", script: "gen.js" },
        { title: "古代架空", input: "https://www.256wxc.com/jiakong/index", script: "gen.js" },
        { title: "穿越重生", input: "https://www.256wxc.com/chuanyue/index", script: "gen.js" },
        { title: "BL同人", input: "https://www.256wxc.com/bltongren/index", script: "gen.js" },
        { title: "GL百合", input: "https://www.256wxc.com/glbaihe/index", script: "gen.js" }, 
        { title: "玄幻科幻", input: "https://www.256wxc.com/xuanhuan/index", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wxc.com/yanqing/index", script: "gen.js" }, 
        { title: "都市言情", input: "https://www.256wxc.com/gudaiyanqing/index", script: "gen.js" }, 
    ]);
}