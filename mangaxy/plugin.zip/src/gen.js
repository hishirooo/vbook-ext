function execute(url, page) {
    if(!page) page = "1"
    var doc = Http.get(url + page).html()
    var element = doc.select("#tblChap .thumb")
    var listBook = []
    for(var el in element){
        var book = element[el]
        listBook.push({
            name: book.text(),
            link: book.get(2).attr("href"),
            cover: "book.match(/url.\'\/\/(.+)\'\)/)[1]",
            description: "",
            host: "https://mangaxy.com"      
        });
    }
    return Response.success(listBook)
}